package User;

import java.io.Serializable;

public class User implements Serializable {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellphone;

    public User(String firstName, String lastName, String username, String password, String cellphone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
    }

    // Getters
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getCellphone() { return cellphone; }

    @Override
    public String toString() {
        return String.join(",",
            firstName,
            lastName,
            username,
            password,
            cellphone
        );
    }

    public static User fromString(String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        
        String[] parts = str.split(",");
        if (parts.length != 5) {
            return null;
        }
        
        try {
            return new User(
                parts[0].trim(),
                parts[1].trim(),
                parts[2].trim(),
                parts[3].trim(),
                parts[4].trim()
            );
        } catch (Exception e) {
            return null;
        }
    }
}