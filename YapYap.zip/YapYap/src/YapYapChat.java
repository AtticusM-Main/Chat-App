
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class YapYapChat extends JFrame {
    private String currentUser;
    private ChatHistoryManager chatHistoryManager = new ChatHistoryManager();
    private String currentChatId;

    // Color Theme - Modern Cream with Purple/Pink Accents
    private static final Color DEEP_PURPLE = new Color(88, 86, 214);
    private static final Color MEDIUM_PURPLE = new Color(139, 92, 246);
    private static final Color SOFT_PINK = new Color(236, 72, 153);
    private static final Color LIGHT_PINK = new Color(251, 207, 232);
    private static final Color SOFT_BLUE = new Color(96, 165, 250);
    private static final Color LIGHT_BLUE = new Color(219, 234, 254);
    private static final Color GRADIENT_START = new Color(139, 92, 246);
    private static final Color GRADIENT_END = new Color(236, 72, 153);
    private static final Color BACKGROUND_CREAM = new Color(255, 251, 240);
    private static final Color PANEL_BACKGROUND = new Color(255, 248, 230);
    private static final Color BORDER_COLOR = new Color(229, 231, 235);

    // UI Components
    private JMenuBar menuBar;
    private JMenu fileMenu, viewMenu, helpMenu;
    private JMenuItem messageHistoryItem, exportChatItem, settingsItem, aboutItem, keyboardShortcutsItem;

    private JSplitPane mainSplitPane;
    private JPanel contactsPanel;
    private JPanel chatPanel;
    private JList<String> contactsList;
    private JPanel messagesPanel;
    private JScrollPane chatScrollPane;
    private JTextArea inputArea;
    private JButton sendButton;
    private JLabel chatTitle;

    // Search components
    private JTextField chatSearchField;
    private JButton chatSearchButton, chatClearSearchButton;
    private JTextField contactsSearchField;
    private JButton contactsSearchButton, contactsClearSearchButton;

    public YapYapChat(String username) {
        this.currentUser = username;
        initializeMenuBar();
        initializeUI();
        loadSampleContacts();
        loadSampleMessages();
        setVisible(true);
    }

    public YapYapChat() {
        this("DefaultUser");
    }

    private void initializeMenuBar() {
        // Menu bar setup
        menuBar = new JMenuBar();
        menuBar.setBackground(DEEP_PURPLE);
        menuBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // File menu
        fileMenu = new JMenu("File");
        styleMenu(fileMenu);

        exportChatItem = new JMenuItem("Export Chat");
        styleMenuItem(exportChatItem);
        exportChatItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_DOWN_MASK));
        exportChatItem.addActionListener(e -> exportCurrentChat());

        settingsItem = new JMenuItem("Settings");
        styleMenuItem(settingsItem);
        settingsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_COMMA, InputEvent.CTRL_DOWN_MASK));
        settingsItem.addActionListener(e -> openSettings());

        JMenuItem exitItem = new JMenuItem("Exit");
        styleMenuItem(exitItem);
        exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));
        exitItem.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) System.exit(0);
        });

        fileMenu.add(exportChatItem);
        fileMenu.addSeparator();
        fileMenu.add(settingsItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // View menu
        viewMenu = new JMenu("View");
        styleMenu(viewMenu);

        messageHistoryItem = new JMenuItem("Message History");
        styleMenuItem(messageHistoryItem);
        messageHistoryItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_DOWN_MASK));
        messageHistoryItem.addActionListener(e -> showMessageHistory());

        JMenuItem refreshItem = new JMenuItem("Refresh Contacts");
        styleMenuItem(refreshItem);
        refreshItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK));
        refreshItem.addActionListener(e -> refreshContacts());

        viewMenu.add(messageHistoryItem);
        viewMenu.addSeparator();
        viewMenu.add(refreshItem);

        // Help menu
        helpMenu = new JMenu("Help");
        styleMenu(helpMenu);

        aboutItem = new JMenuItem("About YapYap");
        styleMenuItem(aboutItem);
        aboutItem.addActionListener(e -> showAbout());

        keyboardShortcutsItem = new JMenuItem("Keyboard Shortcuts");
        styleMenuItem(keyboardShortcutsItem);
        keyboardShortcutsItem.addActionListener(e -> showKeyboardShortcuts());

        helpMenu.add(aboutItem);
        helpMenu.add(keyboardShortcutsItem);

        // Add all menus
        menuBar.add(fileMenu);
        menuBar.add(viewMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);
    }

    private void styleMenu(JMenu menu) {
        menu.setForeground(Color.WHITE);
        menu.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    private void styleMenuItem(JMenuItem item) {
        item.setBackground(Color.WHITE);
        item.setForeground(DEEP_PURPLE);
        item.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        item.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
    }

    private void styleButton(JButton button, Color backgroundColor) {
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(8, 16, 8, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        button.setBorderPainted(false);
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(backgroundColor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(backgroundColor);
            }
        });
    }

    private void initializeUI() {
        setTitle("YapYap - " + currentUser);
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        mainSplitPane.setDividerLocation(350);
        mainSplitPane.setResizeWeight(0.3);
        mainSplitPane.setBackground(BACKGROUND_CREAM);

        // Contacts panel
        contactsPanel = new JPanel(new BorderLayout());
        contactsPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        contactsPanel.setBackground(PANEL_BACKGROUND);

        JLabel contactsHeader = new JLabel("Chats", SwingConstants.CENTER);
        contactsHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        contactsHeader.setForeground(DEEP_PURPLE);
        contactsHeader.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        // Contacts search panel
        JPanel contactsSearchPanel = new JPanel(new BorderLayout());
        contactsSearchPanel.setBackground(PANEL_BACKGROUND);
        contactsSearchPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        contactsSearchField = new JTextField();
        contactsSearchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        contactsSearchField.setToolTipText("Search chats...");
        contactsSearchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        JPanel searchButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
        searchButtonsPanel.setBackground(PANEL_BACKGROUND);

        contactsSearchButton = new JButton("Search");
        styleButton(contactsSearchButton, MEDIUM_PURPLE);

        contactsClearSearchButton = new JButton("Clear");
        styleButton(contactsClearSearchButton, SOFT_PINK);

        searchButtonsPanel.add(contactsSearchButton);
        searchButtonsPanel.add(contactsClearSearchButton);

        contactsSearchPanel.add(contactsSearchField, BorderLayout.CENTER);
        contactsSearchPanel.add(searchButtonsPanel, BorderLayout.SOUTH);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(PANEL_BACKGROUND);
        topPanel.add(contactsHeader, BorderLayout.NORTH);
        topPanel.add(contactsSearchPanel, BorderLayout.SOUTH);
        contactsPanel.add(topPanel, BorderLayout.NORTH);

        contactsList = new JList<>();
        contactsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        contactsList.setCellRenderer(new ContactListRenderer());
        contactsList.setBackground(PANEL_BACKGROUND);
        contactsList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selected = contactsList.getSelectedValue();
                if (selected != null) openChat(selected);
            }
        });

        JScrollPane contactsScroll = new JScrollPane(contactsList);
        contactsScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contactsScroll.getViewport().setBackground(PANEL_BACKGROUND);
        contactsPanel.add(contactsScroll, BorderLayout.CENTER);

        JButton newChatButton = new JButton("+ New Chat");
        styleButton(newChatButton, MEDIUM_PURPLE);
        newChatButton.addActionListener(e -> createNewChat());
        newChatButton.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        contactsPanel.add(newChatButton, BorderLayout.SOUTH);

        // Contact search functionality
        contactsSearchButton.addActionListener(e -> {
            String keyword = contactsSearchField.getText().trim().toLowerCase();
            DefaultListModel<String> model = new DefaultListModel<>();
            for (String contact : chatHistoryManager.getAllContacts()) {
                if (contact.toLowerCase().contains(keyword)) {
                    model.addElement(contact);
                }
            }
            contactsList.setModel(model);
        });

        contactsClearSearchButton.addActionListener(e -> {
            contactsSearchField.setText("");
            refreshContactsList();
        });

        contactsSearchField.addActionListener(e -> contactsSearchButton.doClick());

        // Chat panel
        chatPanel = new JPanel(new BorderLayout());
        chatPanel.setBackground(BACKGROUND_CREAM);

        // Header with gradient and search
        JPanel headerPanel = new GradientPanel();
        headerPanel.setBorder(new EmptyBorder(20, 25, 20, 25));
        headerPanel.setLayout(new BorderLayout());

        chatTitle = new JLabel("Select a chat to start messaging");
        chatTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        chatTitle.setForeground(Color.WHITE);

        JPanel titleSearchPanel = new JPanel(new BorderLayout());
        titleSearchPanel.setOpaque(false);
        titleSearchPanel.add(chatTitle, BorderLayout.WEST);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        searchPanel.setOpaque(false);

        chatSearchField = new JTextField(20);
        chatSearchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatSearchField.setToolTipText("Search messages in this chat...");
        chatSearchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        chatSearchButton = new JButton("Search");
        styleButton(chatSearchButton, Color.WHITE);
        chatSearchButton.setForeground(DEEP_PURPLE);

        chatClearSearchButton = new JButton("Clear");
        styleButton(chatClearSearchButton, Color.WHITE);
        chatClearSearchButton.setForeground(SOFT_PINK);

        searchPanel.add(chatSearchField);
        searchPanel.add(chatSearchButton);
        searchPanel.add(chatClearSearchButton);

        titleSearchPanel.add(searchPanel, BorderLayout.EAST);
        headerPanel.add(titleSearchPanel, BorderLayout.CENTER);
        chatPanel.add(headerPanel, BorderLayout.NORTH);

        // Messages area
        messagesPanel = new JPanel();
        messagesPanel.setLayout(new BoxLayout(messagesPanel, BoxLayout.Y_AXIS));
        messagesPanel.setBackground(BACKGROUND_CREAM);
        messagesPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        chatScrollPane = new JScrollPane(messagesPanel);
        chatScrollPane.setBorder(null);
        chatScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        chatScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        chatScrollPane.getViewport().setBackground(BACKGROUND_CREAM);
        chatPanel.add(chatScrollPane, BorderLayout.CENTER);

        // Input area
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(new EmptyBorder(15, 20, 20, 20));
        inputPanel.setBackground(Color.WHITE);

        inputArea = new JTextArea(3, 20);
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        inputArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputArea.setEnabled(false);
        inputArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        
        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputScroll.setBorder(null);
        inputPanel.add(inputScroll, BorderLayout.CENTER);

        sendButton = new JButton("Send Message");
        styleButton(sendButton, SOFT_PINK);
        sendButton.setEnabled(false);
        sendButton.addActionListener(e -> sendMessage());
        sendButton.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        buttonPanel.add(sendButton, BorderLayout.EAST);
        inputPanel.add(buttonPanel, BorderLayout.SOUTH);

        chatPanel.add(inputPanel, BorderLayout.SOUTH);

        mainSplitPane.setLeftComponent(contactsPanel);
        mainSplitPane.setRightComponent(chatPanel);
        add(mainSplitPane);

        // Event listeners
        inputArea.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !e.isShiftDown()) {
                    sendMessage();
                    e.consume();
                }
            }
        });

        chatSearchButton.addActionListener(e -> searchMessagesInChat());
        chatClearSearchButton.addActionListener(e -> {
            chatSearchField.setText("");
            if(currentChatId != null) openChat(currentChatId);
        });
        chatSearchField.addActionListener(e -> searchMessagesInChat());
    }

    private void searchMessagesInChat() {
        if (currentChatId == null) return;
        
        String keyword = chatSearchField.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            openChat(currentChatId);
            return;
        }

        Chat chat = chatHistoryManager.getChat(currentChatId);
        if (chat != null) {
            messagesPanel.removeAll();
            List<Message> filteredMessages = chat.getMessages().stream()
                .filter(msg -> msg.content.toLowerCase().contains(keyword))
                .collect(Collectors.toList());
            
            for (Message msg : filteredMessages) {
                addMessageBubble(msg);
            }
            
            messagesPanel.revalidate();
            messagesPanel.repaint();
            
            if (filteredMessages.isEmpty()) {
                JLabel noResults = new JLabel("No messages found containing: " + keyword);
                noResults.setFont(new Font("Segoe UI", Font.ITALIC, 14));
                noResults.setForeground(Color.GRAY);
                noResults.setAlignmentX(Component.CENTER_ALIGNMENT);
                messagesPanel.add(Box.createVerticalGlue());
                messagesPanel.add(noResults);
                messagesPanel.add(Box.createVerticalGlue());
            }
        }
    }

    private void refreshContactsList() {
        DefaultListModel<String> model = new DefaultListModel<>();
        for (String contact : chatHistoryManager.getAllContacts()) {
            model.addElement(contact);
        }
        contactsList.setModel(model);
    }

    private void sendMessage() {
        if(currentChatId == null) return;
        String text = inputArea.getText().trim();
        if(text.isEmpty()) return;

        Chat chat = chatHistoryManager.getChat(currentChatId);
        if(chat != null) {
            Message msg = new Message(currentUser, text);
            chat.addMessage(msg);
            addMessageBubble(msg);
            inputArea.setText("");
            SwingUtilities.invokeLater(() -> {
                JScrollBar verticalBar = chatScrollPane.getVerticalScrollBar();
                verticalBar.setValue(verticalBar.getMaximum());
            });
        }
    }

    private void addMessageBubble(Message msg) {
        boolean isFromCurrentUser = msg.sender.equals(currentUser);

        JPanel messageContainer = new JPanel(new BorderLayout());
        messageContainer.setOpaque(false);
        messageContainer.setBorder(new EmptyBorder(8, 20, 8, 20));

        JPanel bubble = createMessageBubble(msg.content, msg.timestamp, isFromCurrentUser);
        messageContainer.add(bubble, BorderLayout.CENTER);

        messagesPanel.add(messageContainer);
        messagesPanel.revalidate();
        messagesPanel.repaint();
    }

    private JPanel createMessageBubble(String content, Date timestamp, boolean isFromCurrentUser) {
        JPanel bubble = new JPanel(new BorderLayout());

        Color backgroundColor = isFromCurrentUser ? SOFT_PINK : SOFT_BLUE;
        Color textColor = Color.WHITE;

        bubble.setBackground(backgroundColor);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);

        JTextArea messageText = new JTextArea(content);
        messageText.setEditable(false);
        messageText.setOpaque(false);
        messageText.setLineWrap(true);
        messageText.setWrapStyleWord(true);
        messageText.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageText.setForeground(textColor);

        FontMetrics fm = messageText.getFontMetrics(messageText.getFont());
        int maxWidth = 350;
        int textWidth = fm.stringWidth(content);

        if(textWidth > maxWidth) {
            messageText.setColumns(40);
            messageText.setRows(0);
        } else {
            messageText.setColumns(content.length() + 3);
            messageText.setRows(1);
        }

        contentPanel.add(messageText, BorderLayout.CENTER);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        JLabel timeLabel = new JLabel(sdf.format(timestamp));
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        timeLabel.setForeground(new Color(255, 255, 255, 200));
        timeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        timePanel.setOpaque(false);
        timePanel.add(timeLabel);

        contentPanel.add(timePanel, BorderLayout.SOUTH);

        bubble.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(18, backgroundColor),
            new EmptyBorder(15, 18, 15, 18)
        ));

        bubble.add(contentPanel, BorderLayout.CENTER);

        JPanel container = new JPanel(new FlowLayout(isFromCurrentUser ? FlowLayout.RIGHT : FlowLayout.LEFT, 10, 0));
        container.setOpaque(false);
        container.add(bubble);

        return container;
    }

    private void exportCurrentChat() {
        if(currentChatId == null) {
            JOptionPane.showMessageDialog(this, "Please select a chat to export.", "No Chat Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Chat chat = chatHistoryManager.getChat(currentChatId);
        if(chat == null) return;

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Chat");
        String sanitizedName = currentChatId.replaceAll("[^a-zA-Z0-9]", "_");
        fileChooser.setSelectedFile(new File(sanitizedName + "_chat.txt"));
        
        FileNameExtensionFilter txtFilter = new FileNameExtensionFilter("Text Files (*.txt)", "txt");
        FileNameExtensionFilter jsonFilter = new FileNameExtensionFilter("JSON Files (*.json)", "json");
        FileNameExtensionFilter csvFilter = new FileNameExtensionFilter("CSV Files (*.csv)", "csv");
        
        fileChooser.addChoosableFileFilter(txtFilter);
        fileChooser.addChoosableFileFilter(jsonFilter);
        fileChooser.addChoosableFileFilter(csvFilter);
        fileChooser.setFileFilter(txtFilter);

        if(fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String extension = "txt";

            if(fileChooser.getFileFilter() == jsonFilter) extension = "json";
            else if(fileChooser.getFileFilter() == csvFilter) extension = "csv";

            if(!file.getName().toLowerCase().endsWith("." + extension)) {
                file = new File(file.getAbsolutePath() + "." + extension);
            }

            try {
                ExportManager exportManager = new ExportManager();
                List<Message> messages = chat.getMessages();
                switch(extension) {
                    case "json":
                        exportManager.exportToJSON(messages, file.getAbsolutePath());
                        break;
                    case "csv":
                        exportManager.exportToCSV(messages, file.getAbsolutePath());
                        break;
                    default:
                        exportManager.exportToTXT(messages, file.getAbsolutePath());
                }
                JOptionPane.showMessageDialog(this, 
                    "Chat exported successfully to:\n" + file.getAbsolutePath(), 
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);
            } catch(IOException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error exporting chat: " + e.getMessage(), 
                    "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void openSettings() {
        JOptionPane.showMessageDialog(this, 
            "Settings feature coming soon!\n\nFuture features will include:\n• Theme customization\n• Notification preferences\n• Privacy settings\n• Export preferences", 
            "Settings", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showMessageHistory() {
        MessageHistoryDialog dialog = new MessageHistoryDialog(this, chatHistoryManager, currentUser);
        dialog.setVisible(true);
    }

    private void refreshContacts() {
        refreshContactsList();
        JOptionPane.showMessageDialog(this, "Contacts refreshed successfully.", "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAbout() {
        String aboutMessage = "<html><body style='font-family: Segoe UI; padding: 10px; width: 300px;'>" +
            "<h2 style='color: #5856d6; text-align: center;'>YapYap Chat</h2>" +
            "<p style='text-align: center; color: #666;'>Version 1.0</p>" +
            "<hr style='border: 1px solid #ddd;'>" +
            "<p><b>Features:</b></p>" +
            "<ul>" +
            "<li>Modern cream-themed UI with purple/pink accents</li>" +
            "<li>Real-time messaging with styled bubbles</li>" +
            "<li>Contact management with search</li>" +
            "<li>Message history and search functionality</li>" +
            "<li>Export chats in multiple formats</li>" +
            "<li>South African phone number validation</li>" +
            "</ul>" +
            "<p style='text-align: center; color: #666; margin-top: 20px;'>" +
            "Built with Java Swing<br/>© 2024 YapYap Team</p>" +
            "</body></html>";
        
        JOptionPane.showMessageDialog(this, aboutMessage, "About YapYap", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showKeyboardShortcuts() {
        String shortcutsHTML = "<html><body style='font-family: Segoe UI; padding: 15px; width: 350px;'>" +
            "<h3 style='color: #5856d6; text-align: center;'>Keyboard Shortcuts</h3>" +
            "<table cellpadding='8' style='width: 100%;'>" +
            "<tr><td><b>Ctrl+H</b></td><td>Open Message History</td></tr>" +
            "<tr><td><b>Ctrl+E</b></td><td>Export Current Chat</td></tr>" +
            "<tr><td><b>Ctrl+R</b></td><td>Refresh Contacts</td></tr>" +
            "<tr><td><b>Ctrl+,</b></td><td>Open Settings</td></tr>" +
            "<tr><td><b>Ctrl+Q</b></td><td>Exit Application</td></tr>" +
            "<tr><td><b>Enter</b></td><td>Send Message</td></tr>" +
            "<tr><td><b>Shift+Enter</b></td><td>New Line in Message</td></tr>" +
            "<tr><td><b>Tab</b></td><td>Navigate between components</td></tr>" +
            "</table>" +
            "</body></html>";
            
        JDialog dialog = new JDialog(this, "Keyboard Shortcuts", true);
        JLabel label = new JLabel(shortcutsHTML);
        label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dialog.add(new JScrollPane(label));
        dialog.setSize(450, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void loadSampleContacts() {
        String[] sampleContacts = {
            "Alice Johnson (+27821234567)",
            "Bob Smith (+27829876543)", 
            "Charlie Brown (+27731234567)",
            "Diana Prince (+27846123456)",
            "Emma Watson (+27723456789)",
            "Frank Miller (+27812345678)",
            "Grace Lee (+27834567890)"
        };

        DefaultListModel<String> model = new DefaultListModel<>();
        for(String contact : sampleContacts) {
            model.addElement(contact);
            chatHistoryManager.addChat(new Chat(contact));
        }
        contactsList.setModel(model);
    }

    private void loadSampleMessages() {
        // Alice conversation
        Chat alice = chatHistoryManager.getChat("Alice Johnson (+27821234567)");
        if(alice != null) {
            alice.addMessage(new Message("Alice Johnson", "Hey! How are you doing today?"));
            alice.addMessage(new Message(currentUser, "Hi Alice! I'm doing great, thanks for asking!"));
            alice.addMessage(new Message("Alice Johnson", "That's wonderful to hear! I was thinking we should catch up soon."));
            alice.addMessage(new Message(currentUser, "Absolutely! How about lunch this weekend?"));
            alice.addMessage(new Message("Alice Johnson", "Perfect! Saturday works great for me."));
        }

        // Bob conversation
        Chat bob = chatHistoryManager.getChat("Bob Smith (+27829876543)");
        if(bob != null) {
            bob.addMessage(new Message("Bob Smith", "Did you see the game last night? It was incredible!"));
            bob.addMessage(new Message(currentUser, "No, I missed it! Who won?"));
            bob.addMessage(new Message("Bob Smith", "It was an amazing match! The final score was 3-2, went into overtime."));
            bob.addMessage(new Message(currentUser, "Wow, sounds intense! I'll have to catch the highlights."));
        }

        // Charlie conversation  
        Chat charlie = chatHistoryManager.getChat("Charlie Brown (+27731234567)");
        if(charlie != null) {
            charlie.addMessage(new Message(currentUser, "Hey Charlie, are we still on for the project meeting tomorrow?"));
            charlie.addMessage(new Message("Charlie Brown", "Absolutely! I've prepared all the documents we discussed."));
            charlie.addMessage(new Message(currentUser, "Great! See you at 2 PM in the conference room."));
            charlie.addMessage(new Message("Charlie Brown", "Perfect, looking forward to it!"));
        }

        // Diana conversation
        Chat diana = chatHistoryManager.getChat("Diana Prince (+27846123456)");
        if(diana != null) {
            diana.addMessage(new Message("Diana Prince", "Thanks for helping me with the presentation yesterday!"));
            diana.addMessage(new Message(currentUser, "You're very welcome! How did it go?"));
            diana.addMessage(new Message("Diana Prince", "It went fantastic! The client loved our proposal."));
        }

        // Emma conversation
        Chat emma = chatHistoryManager.getChat("Emma Watson (+27723456789)");
        if(emma != null) {
            emma.addMessage(new Message("Emma Watson", "Are you free for coffee this afternoon?"));
            emma.addMessage(new Message(currentUser, "I'd love to, but I'm swamped with work today. How about tomorrow?"));
            emma.addMessage(new Message("Emma Watson", "Tomorrow sounds perfect! The usual place?"));
            emma.addMessage(new Message(currentUser, "Yes, see you at 3 PM!"));
        }
    }

    private void openChat(String contact) {
        currentChatId = contact;
        String displayName = contact.split(" \\(")[0]; // Extract name without phone number
        chatTitle.setText("Chat with " + displayName);
        
        messagesPanel.removeAll();
        Chat chat = chatHistoryManager.getChat(contact);
        if(chat != null) {
            for(Message msg : chat.getMessages()) {
                addMessageBubble(msg);
            }
        }
        
        inputArea.setEnabled(true);
        sendButton.setEnabled(true);
        inputArea.requestFocus();
        chatSearchField.setText("");
        
        messagesPanel.revalidate();
        messagesPanel.repaint();
        
        SwingUtilities.invokeLater(() -> {
            JScrollBar verticalBar = chatScrollPane.getVerticalScrollBar();
            verticalBar.setValue(verticalBar.getMaximum());
        });
    }

    private void createNewChat() {
        String name = JOptionPane.showInputDialog(this, "Enter contact name:", "New Chat", JOptionPane.QUESTION_MESSAGE);
        if(name == null || name.trim().isEmpty()) return;
        
        String phone = showSouthAfricanNumberDialog(name.trim());
        if(phone != null) {
            String fullContact = name.trim() + " (" + phone + ")";
            if(!chatHistoryManager.hasChat(fullContact)) {
                chatHistoryManager.addChat(new Chat(fullContact));
                DefaultListModel<String> model = (DefaultListModel<String>)contactsList.getModel();
                if(model != null) {
                    model.addElement(fullContact);
                }
                contactsList.setSelectedValue(fullContact, true);
                JOptionPane.showMessageDialog(this, "Contact added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "This contact already exists!", "Duplicate Contact", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private String showSouthAfricanNumberDialog(String name) {
        JDialog dialog = new JDialog(this, "Add Number for " + name, true);
        dialog.setSize(450, 250);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(new EmptyBorder(25, 25, 25, 25));
        mainPanel.setBackground(Color.WHITE);
        GridBagConstraints constraints = new GridBagConstraints();

        JLabel titleLabel = new JLabel("Enter phone number for " + name);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(DEEP_PURPLE);
        constraints.gridx = 0; 
        constraints.gridy = 0; 
        constraints.gridwidth = 2; 
        constraints.insets = new Insets(0, 0, 20, 0);
        mainPanel.add(titleLabel, constraints);

        JLabel countryLabel = new JLabel("+27");
        countryLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        countryLabel.setForeground(DEEP_PURPLE);
        constraints.gridx = 0; 
        constraints.gridy = 1; 
        constraints.gridwidth = 1; 
        constraints.insets = new Insets(0, 0, 0, 8);
        mainPanel.add(countryLabel, constraints);

        JTextField phoneField = new JTextField(15);
        phoneField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        phoneField.setToolTipText("Enter 9-digit number (e.g., 821234567)");
        phoneField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(LIGHT_PINK, 2),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        constraints.gridx = 1; 
        constraints.gridy = 1; 
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(0, 0, 0, 0);
        mainPanel.add(phoneField, constraints);

        JLabel exampleLabel = new JLabel("Example: 821234567 (must start with 6, 7, 8, or 9)");
        exampleLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        exampleLabel.setForeground(Color.GRAY);
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(8, 0, 20, 0);
        mainPanel.add(exampleLabel, constraints);

        dialog.add(mainPanel, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 15));
        buttonsPanel.setBackground(Color.WHITE);
        
        JButton okButton = new JButton("Add Contact");
        styleButton(okButton, MEDIUM_PURPLE);
        okButton.setPreferredSize(new Dimension(120, 35));
        
        JButton cancelButton = new JButton("Cancel");
        styleButton(cancelButton, SOFT_PINK);
        cancelButton.setPreferredSize(new Dimension(100, 35));

        final String[] result = {null};

        okButton.addActionListener(e -> {
            String number = phoneField.getText().trim();
            if(validateSouthAfricanNumber(number)) {
                result[0] = "+27" + number;
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog,
                    "Please enter a valid 9-digit South African number\n" +
                    "• Must be exactly 9 digits\n" +
                    "• Must start with 6, 7, 8, or 9\n" +
                    "• Example: 821234567",
                    "Invalid Number Format", JOptionPane.ERROR_MESSAGE);
                phoneField.requestFocus();
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonsPanel.add(cancelButton);
        buttonsPanel.add(okButton);
        dialog.add(buttonsPanel, BorderLayout.SOUTH);

        phoneField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER) {
                    okButton.doClick();
                }
            }
        });

        phoneField.requestFocus();
        dialog.setVisible(true);
        return result[0];
    }

    private boolean validateSouthAfricanNumber(String number) {
        return number.matches("[6-9]\\d{8}");
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
        } catch(Exception e) {
            // Fall back to default look and feel
        }
        
        SwingUtilities.invokeLater(() -> {
            new YapYapChat("John Doe");
        });
    }

    // Inner Classes

    class Chat {
        String contact;
        List<Message> messages = new ArrayList<>();

        Chat(String contact) { 
            this.contact = contact; 
        }

        void addMessage(Message message) { 
            messages.add(message); 
        }
        
        List<Message> getMessages() { 
            return messages; 
        }
    }

    class Message {
        String messageHash;
        String sender;
        String content;
        Date timestamp;

        Message(String sender, String content) {
            this.sender = sender;
            this.content = content;
            this.timestamp = new Date();
            this.messageHash = generateHash();
        }

        private String generateHash() {
            try {
                String input = sender + content + timestamp.toString() + Math.random();
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
                StringBuilder hexString = new StringBuilder();
                for(byte b : hash) {
                    String hex = Integer.toHexString(0xff & b);
                    if(hex.length() == 1) {
                        hexString.append('0');
                    }
                    hexString.append(hex);
                }
                return hexString.substring(0, 16); // Return first 16 characters
            } catch(NoSuchAlgorithmException e) {
                return String.valueOf((sender + content + timestamp.toString()).hashCode());
            }
        }

        public String getHash() { 
            return messageHash; 
        }
    }

    class ChatHistoryManager {
        private Map<String, Chat> chats = new HashMap<>();

        void addChat(Chat chat) { 
            chats.put(chat.contact, chat); 
        }
        
        Chat getChat(String contactKey) { 
            return chats.get(contactKey); 
        }
        
        boolean hasChat(String contactKey) { 
            return chats.containsKey(contactKey); 
        }
        
        Collection<String> getAllContacts() { 
            return chats.keySet(); 
        }

        List<Message> getAllMessagesSorted() {
            List<Message> allMessages = new ArrayList<>();
            for(Chat chat : chats.values()) {
                allMessages.addAll(chat.getMessages());
            }
            allMessages.sort(Comparator.comparing(message -> message.timestamp));
            return allMessages;
        }

        String findChatNameForMessage(Message message) {
            for(Map.Entry<String, Chat> entry : chats.entrySet()) {
                if(entry.getValue().getMessages().contains(message)) {
                    return entry.getKey().split(" \\(")[0]; // Return name without phone number
                }
            }
            return "Unknown";
        }
    }

    class ExportManager {
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        void exportToTXT(List<Message> messages, String filePath) throws IOException {
            try(PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filePath), StandardCharsets.UTF_8))) {
                writer.println("=".repeat(60));
                writer.println("YapYap Chat Export");
                writer.println("Export Date: " + dateFormat.format(new Date()));
                writer.println("Total Messages: " + messages.size());
                writer.println("=".repeat(60));
                writer.println();
                
                for(Message message : messages) {
                    writer.printf("[%s] %s: %s%n", 
                        dateFormat.format(message.timestamp), 
                        message.sender, 
                        message.content);
                }
                
                writer.println();
                writer.println("=".repeat(60));
                writer.println("End of Export");
            }
        }

        void exportToJSON(List<Message> messages, String filePath) throws IOException {
            Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .create();
                
            try(Writer writer = new OutputStreamWriter(new FileOutputStream(filePath), StandardCharsets.UTF_8)) {
                Map<String, Object> exportData = new HashMap<>();
                exportData.put("exportDate", dateFormat.format(new Date()));
                exportData.put("totalMessages", messages.size());
                exportData.put("messages", messages);
                
                gson.toJson(exportData, writer);
            }
        }

        void exportToCSV(List<Message> messages, String filePath) throws IOException {
            try(PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filePath), StandardCharsets.UTF_8))) {
                writer.println("Timestamp,Sender,Content,MessageHash");
                
                for(Message message : messages) {
                    String content = message.content.replace("\"", "\"\""); // Escape quotes
                    writer.printf("\"%s\",\"%s\",\"%s\",\"%s\"%n", 
                        dateFormat.format(message.timestamp), 
                        message.sender, 
                        content,
                        message.getHash());
                }
            }
        }
    }

    class ContactListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                                                      int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            String contact = (String) value;
            String displayName = contact.split(" \\(")[0]; // Extract name without phone number
            label.setText(displayName);
            
            label.setBorder(new EmptyBorder(15, 20, 15, 20));
            label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            
            if(isSelected) {
                label.setBackground(MEDIUM_PURPLE);
                label.setForeground(Color.WHITE);
            } else {
                label.setBackground(Color.WHITE);
                label.setForeground(DEEP_PURPLE);
            }
            
            label.setOpaque(true);
            return label;
        }
    }

    class GradientPanel extends JPanel {
        public GradientPanel() {
            setLayout(new BorderLayout());
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g2d = (Graphics2D) graphics;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            GradientPaint gradientPaint = new GradientPaint(
                0, 0, GRADIENT_START, 
                getWidth(), 0, GRADIENT_END
            );
            
            g2d.setPaint(gradientPaint);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();
        }
    }

    class RoundedBorder implements Border {
        private int radius;
        private Color color;

        RoundedBorder(int radius, Color color) {
            this.radius = radius;
            this.color = color;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius + 1, this.radius + 1, this.radius + 2, this.radius);
        }

        public boolean isBorderOpaque() {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(color);
            g2d.fillRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }

    // Message History Dialog as Inner Class
    class MessageHistoryDialog extends JDialog {
        private JTabbedPane tabbedPane;
        private JTextField searchField;
        private JButton searchButton, clearSearchButton, exportAllButton, closeButton;

        public MessageHistoryDialog(JFrame parent, ChatHistoryManager manager, String user) {
            super(parent, "Message History", true);
            
            initializeDialog();
            createTabs();
            setupEventHandlers();
        }

        private void initializeDialog() {
            setSize(800, 600);
            setLocationRelativeTo(getParent());
            setLayout(new BorderLayout());
            getContentPane().setBackground(BACKGROUND_CREAM);

            // Header panel
            JPanel headerPanel = createHeaderPanel();
            add(headerPanel, BorderLayout.NORTH);

            // Tabbed pane
            tabbedPane = new JTabbedPane();
            tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            tabbedPane.setBackground(PANEL_BACKGROUND);
            add(tabbedPane, BorderLayout.CENTER);

            // Footer panel with close button
            JPanel footerPanel = createFooterPanel();
            add(footerPanel, BorderLayout.SOUTH);
        }

        private JPanel createHeaderPanel() {
            JPanel headerPanel = new JPanel(new BorderLayout());
            headerPanel.setBackground(DEEP_PURPLE);
            headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

            JLabel titleLabel = new JLabel("Message History");
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            titleLabel.setForeground(Color.WHITE);

            JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            searchPanel.setOpaque(false);

            searchField = new JTextField(20);
            searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            searchField.setToolTipText("Search all messages...");
            searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
            ));

            searchButton = new JButton("Search");
            styleButton(searchButton, Color.WHITE);
            searchButton.setForeground(DEEP_PURPLE);

            clearSearchButton = new JButton("Clear");
            styleButton(clearSearchButton, Color.WHITE);
            clearSearchButton.setForeground(SOFT_PINK);

            exportAllButton = new JButton("Export All");
            styleButton(exportAllButton, SOFT_PINK);

            searchPanel.add(searchField);
            searchPanel.add(searchButton);
            searchPanel.add(clearSearchButton);
            searchPanel.add(exportAllButton);

            headerPanel.add(titleLabel, BorderLayout.WEST);
            headerPanel.add(searchPanel, BorderLayout.EAST);

            return headerPanel;
        }

        private JPanel createFooterPanel() {
            JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
            footerPanel.setBackground(BACKGROUND_CREAM);

            closeButton = new JButton("Close");
            styleButton(closeButton, MEDIUM_PURPLE);
            closeButton.setPreferredSize(new Dimension(120, 40));

            footerPanel.add(closeButton);
            return footerPanel;
        }

        private void createTabs() {
            // All Messages Tab
            JScrollPane allMessagesTab = createAllMessagesTab();
            tabbedPane.addTab("All Messages", allMessagesTab);

            // Individual contact tabs
            for(String contact : chatHistoryManager.getAllContacts()) {
                String displayName = contact.split(" \\(")[0]; // Extract name without phone number
                JScrollPane contactTab = createContactTab(contact);
                tabbedPane.addTab(displayName, contactTab);
            }
        }

        private JScrollPane createAllMessagesTab() {
            List<Message> allMessages = chatHistoryManager.getAllMessagesSorted();
            JPanel messagesPanel = createMessagesPanel(allMessages, true);
            
            JScrollPane scrollPane = new JScrollPane(messagesPanel);
            scrollPane.setBorder(null);
            scrollPane.getViewport().setBackground(BACKGROUND_CREAM);
            
            return scrollPane;
        }

        private JScrollPane createContactTab(String contact) {
            Chat chat = chatHistoryManager.getChat(contact);
            List<Message> messages = chat != null ? chat.getMessages() : new ArrayList<>();
            JPanel messagesPanel = createMessagesPanel(messages, false);
            
            JScrollPane scrollPane = new JScrollPane(messagesPanel);
            scrollPane.setBorder(null);
            scrollPane.getViewport().setBackground(BACKGROUND_CREAM);
            
            return scrollPane;
        }

        private JPanel createMessagesPanel(List<Message> messages, boolean showContactNames) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBackground(BACKGROUND_CREAM);
            panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            if(messages.isEmpty()) {
                JLabel noMessagesLabel = new JLabel("No messages found");
                noMessagesLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));
                noMessagesLabel.setForeground(Color.GRAY);
                noMessagesLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                panel.add(Box.createVerticalGlue());
                panel.add(noMessagesLabel);
                panel.add(Box.createVerticalGlue());
            } else {
                for(Message message : messages) {
                    JPanel messagePanel = createMessagePanel(message, showContactNames);
                    panel.add(messagePanel);
                    panel.add(Box.createVerticalStrut(8));
                }
            }

            return panel;
        }

        private JPanel createMessagePanel(Message message, boolean showContactName) {
            JPanel messagePanel = new JPanel(new BorderLayout());
            messagePanel.setBackground(Color.WHITE);
            messagePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(229, 231, 235), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
            ));

            boolean isFromCurrentUser = message.sender.equals(currentUser);

            JPanel headerPanel = new JPanel(new BorderLayout());
            headerPanel.setOpaque(false);

            String senderText = showContactName && !isFromCurrentUser ? 
                chatHistoryManager.findChatNameForMessage(message) : 
                message.sender;

            JLabel senderLabel = new JLabel(senderText);
            senderLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            senderLabel.setForeground(isFromCurrentUser ? SOFT_PINK : MEDIUM_PURPLE);

            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss");
            JLabel timestampLabel = new JLabel(dateFormat.format(message.timestamp));
            timestampLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            timestampLabel.setForeground(Color.GRAY);

            headerPanel.add(senderLabel, BorderLayout.WEST);
            headerPanel.add(timestampLabel, BorderLayout.EAST);

            JTextArea contentArea = new JTextArea(message.content);
            contentArea.setEditable(false);
            contentArea.setOpaque(false);
            contentArea.setLineWrap(true);
            contentArea.setWrapStyleWord(true);
            contentArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            contentArea.setForeground(new Color(51, 51, 51));
            contentArea.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));

            messagePanel.add(headerPanel, BorderLayout.NORTH);
            messagePanel.add(contentArea, BorderLayout.CENTER);

            return messagePanel;
        }

        private void setupEventHandlers() {
            closeButton.addActionListener(e -> dispose());

            searchButton.addActionListener(e -> performSearch());
            clearSearchButton.addActionListener(e -> clearSearch());
            searchField.addActionListener(e -> performSearch());

            exportAllButton.addActionListener(e -> exportAllMessages());
        }

        private void performSearch() {
            String keyword = searchField.getText().trim().toLowerCase();
            if(keyword.isEmpty()) {
                clearSearch();
                return;
            }

            List<Message> allMessages = chatHistoryManager.getAllMessagesSorted();
            List<Message> filteredMessages = allMessages.stream()
                .filter(msg -> msg.content.toLowerCase().contains(keyword) || 
                              msg.sender.toLowerCase().contains(keyword))
                .collect(Collectors.toList());

            // Update the first tab with search results
            JPanel searchResultsPanel = createMessagesPanel(filteredMessages, true);
            JScrollPane searchScrollPane = new JScrollPane(searchResultsPanel);
            searchScrollPane.setBorder(null);
            searchScrollPane.getViewport().setBackground(BACKGROUND_CREAM);

            tabbedPane.setComponentAt(0, searchScrollPane);
            tabbedPane.setTitleAt(0, "Search Results (" + filteredMessages.size() + ")");
            tabbedPane.setSelectedIndex(0);
        }

        private void clearSearch() {
            searchField.setText("");
            JScrollPane allMessagesTab = createAllMessagesTab();
            tabbedPane.setComponentAt(0, allMessagesTab);
            tabbedPane.setTitleAt(0, "All Messages");
        }

        private void exportAllMessages() {
            List<Message> allMessages = chatHistoryManager.getAllMessagesSorted();
            if(allMessages.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No messages to export.", "No Data", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Export All Messages");
            fileChooser.setSelectedFile(new File("all_messages_export.txt"));

            FileNameExtensionFilter txtFilter = new FileNameExtensionFilter("Text Files (*.txt)", "txt");
            FileNameExtensionFilter jsonFilter = new FileNameExtensionFilter("JSON Files (*.json)", "json");
            FileNameExtensionFilter csvFilter = new FileNameExtensionFilter("CSV Files (*.csv)", "csv");

            fileChooser.addChoosableFileFilter(txtFilter);
            fileChooser.addChoosableFileFilter(jsonFilter);
            fileChooser.addChoosableFileFilter(csvFilter);
            fileChooser.setFileFilter(txtFilter);

            if(fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                String extension = "txt";

                if(fileChooser.getFileFilter() == jsonFilter) extension = "json";
                else if(fileChooser.getFileFilter() == csvFilter) extension = "csv";

                if(!file.getName().toLowerCase().endsWith("." + extension)) {
                    file = new File(file.getAbsolutePath() + "." + extension);
                }

                try {
                    ExportManager exportManager = new ExportManager();
                    switch(extension) {
                        case "json":
                            exportManager.exportToJSON(allMessages, file.getAbsolutePath());
                            break;
                        case "csv":
                            exportManager.exportToCSV(allMessages, file.getAbsolutePath());
                            break;
                        default:
                            exportManager.exportToTXT(allMessages, file.getAbsolutePath());
                    }
                    JOptionPane.showMessageDialog(this, 
                        "All messages exported successfully to:\n" + file.getAbsolutePath(), 
                        "Export Successful", JOptionPane.INFORMATION_MESSAGE);
                } catch(IOException e) {
                    JOptionPane.showMessageDialog(this, 
                        "Error exporting messages: " + e.getMessage(), 
                        "Export Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}
