import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends javax.swing.JFrame {
    private static final String FILE_PATH = System.getProperty("user.home") + "/users.txt";
    private Map<String, User> users = new HashMap<>();
    private RegistrationFrame registrationFrame;
    
    // Components
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnExit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField txtUsername;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JCheckBox chkShowPassword;

    public LoginFrame(RegistrationFrame registrationFrame) {
        this.registrationFrame = registrationFrame;
        this.users = registrationFrame.users; // Use the same users map
        initComponents();
        loadUsers();
        setLocationRelativeTo(null);
    }

    // Constructor for standalone use
    public LoginFrame() {
        this.registrationFrame = null;
        initComponents();
        loadUsers();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        chkShowPassword = new javax.swing.JCheckBox();
        btnLogin = new javax.swing.JButton();
        btnRegister = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("YapYap - Login");
        setResizable(false);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24));
        jLabel3.setText("LOGIN");
        jLabel3.setForeground(new Color(0, 128, 128));
        
        jLabel1.setText("Username:");
        jLabel1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        jLabel2.setText("Password:");
        jLabel2.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        chkShowPassword.setText("Show Password");
        chkShowPassword.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chkShowPassword.addActionListener(this::chkShowPasswordActionPerformed);

        btnLogin.setText("Login");
        btnLogin.setBackground(new Color(0, 128, 128));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.addActionListener(this::btnLoginActionPerformed);

        btnRegister.setText("Register");
        btnRegister.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnRegister.addActionListener(this::btnRegisterActionPerformed);

        btnExit.setText("Exit");
        btnExit.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnExit.addActionListener(this::btnExitActionPerformed);

        // Add Enter key listener to password field
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    btnLoginActionPerformed(null);
                }
            }
        });

        // Add Enter key listener to username field
        txtUsername.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    txtPassword.requestFocus();
                }
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtUsername)
                            .addComponent(txtPassword, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(chkShowPassword)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(chkShowPassword)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
        );

        pack();
    }

    private void chkShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {
        if (chkShowPassword.isSelected()) {
            txtPassword.setEchoChar((char) 0); // Show password
        } else {
            txtPassword.setEchoChar('*'); // Hide password
        }
    }

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        // Validate input
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your username.", 
                "Error", JOptionPane.ERROR_MESSAGE);
            txtUsername.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your password.", 
                "Error", JOptionPane.ERROR_MESSAGE);
            txtPassword.requestFocus();
            return;
        }

        // Check credentials
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            // Successful login
            JOptionPane.showMessageDialog(this, 
                "Welcome back, " + user.getFirstName() + " " + user.getLastName() + "!", 
                "Login Successful", JOptionPane.INFORMATION_MESSAGE);
            
            // Open YapYapChat with the user's full name
            String fullName = user.getFirstName() + " " + user.getLastName();
            SwingUtilities.invokeLater(() -> {
                YapYapChat chatWindow = new YapYapChat(fullName);
                chatWindow.setVisible(true);
            });
            
            // Close login window
            this.dispose();
            
        } else {
            // Failed login
            JOptionPane.showMessageDialog(this, 
                "Invalid username or password.\nPlease try again.", 
                "Login Failed", JOptionPane.ERROR_MESSAGE);
            txtPassword.setText(""); // Clear password field
            txtUsername.requestFocus();
        }
    }

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {
        if (registrationFrame != null) {
            registrationFrame.setVisible(true);
        } else {
            RegistrationFrame regFrame = new RegistrationFrame();
            regFrame.setVisible(true);
        }
        this.dispose();
    }

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to exit?",
            "Exit Confirmation",
            JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void loadUsers() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                User user = User.fromString(line);
                if (user != null) {
                    users.put(user.getUsername(), user);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading user data: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Set system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
        } catch (Exception e) {
            // Fall back to default look and feel
        }

        EventQueue.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
