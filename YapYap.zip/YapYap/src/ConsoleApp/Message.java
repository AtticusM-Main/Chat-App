package ConsoleApp;

import java.util.Date;

public class Message {
    private final String content;
    private final String sender;
    private final String recipient;
    private final String hash;
    private final Date timestamp;
    private MessageStatus status;

    public Message(String content, String sender, String recipient) {
        this.content = content;
        this.sender = sender;
        this.recipient = recipient;
        this.timestamp = new Date();
        this.hash = generateHash();
        this.status = MessageStatus.SENT;
    }

    private String generateHash() {
        return sender.substring(0, 2) + 
               recipient.substring(recipient.length() - 2) + 
               timestamp.getTime();
    }

    // Getters and other methods
    public enum MessageStatus { SENT, DELIVERED, READ }
}